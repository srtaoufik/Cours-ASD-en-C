struct noeud {
  int info;
  struct noeud *sag;
  struct noeud *sad;
};

struct noeud *creer_arbre(void);
unsigned arbre_vide(struct noeud*);
struct noeud *construire(int, struct noeud*, struct noeud*);
struct noeud *gauche(struct noeud*);
struct noeud *droite(struct noeud*);
int lire_racine(struct noeud*);
void afficher(struct noeud*);
void incrementer(struct noeud*);
void parcoursInfixe(struct noeud *, void (*oper)(struct noeud *));
unsigned Taille (struct noeud*);
unsigned NBTermineaux (struct noeud*);
unsigned hauteur(struct noeud*);
int max_value(struct noeud*);




