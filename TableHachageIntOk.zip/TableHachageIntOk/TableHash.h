
#include "Liste.h"

void createHashTab();
void insert (int x);
struct cellule* search(int x);
void removee (int x);
void afficherHashTab() ;
