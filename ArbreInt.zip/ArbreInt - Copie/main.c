#include <stdio.h>
#include <stdlib.h>

#include "ArbreInt.h"
int main() {
  struct noeud *Arbre;

  Arbre = construire(5, construire(7, construire(4, NULL, NULL), construire(2, NULL, NULL)), construire(9, construire(6, NULL, NULL), construire(8, NULL, NULL)));

  printf ("\n le nb des noeuds = %u \n", Taille(Arbre));
  printf ("\n le nb des termineaux = %u \n", NBTermineaux(Arbre));
  printf ("\n la hauteur de l'arbre est = %u \n", hauteur(Arbre));
  printf ("\n la valeur Max est = %d \n ", max_value(Arbre));

  printf("\n les elements de l'arbre en parcours infixe est: \n ");
  parcoursInfixe(Arbre, afficher);

  parcoursInfixe(Arbre, incrementer);

  printf("\n apres incrementation \n ");
  printf("\n les elements de l'arbre en parcours infixe est: \n ");
  parcoursInfixe(Arbre, afficher);

}
