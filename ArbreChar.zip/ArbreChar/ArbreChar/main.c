#include <stdio.h>
#include <stdlib.h>
#include "Arbre.h"
char main() {
  struct noeud *Arbre;
  Arbre =creer_arbre();
  Arbre = construire('*',
        construire('/', construire('5', NULL, NULL), construire('2', NULL, NULL)),
        construire('-', construire('3', NULL, NULL), construire('8', NULL, NULL))
    );
  printf ("\n le nb des noeuds = %u \n", Taille(Arbre));
  printf  ("\n le nb des termineaux = %u \n", NBTermineaux(Arbre));
  printf ("\n la hauteur de l'arbre est = %u \n", hauteur(Arbre));

  printf("\n les elements de l'arbre en parcours infixe est: \n ");
  parcoursInfixe(Arbre);



printf("\n l'evaluation dans N de lexpression est =%d \n ", evaluer_expression(Arbre));
printf("\n l'evaluation dans R de lexpression est =%.2f\n ", evaluer_Relle(Arbre));


}
