
struct noeud {
  char info;
  struct noeud *sag;
  struct noeud *sad;
};

struct noeud *creer_arbre(void);
unsigned arbre_vide(struct noeud*);
struct noeud *construire(char, struct noeud*, struct noeud*);
struct noeud *gauche(struct noeud*);
struct noeud *droite(struct noeud*);
char lire_racine(struct noeud*);
void visiter(struct noeud*);
void parcoursInfixe(struct noeud *);
unsigned Taille (struct noeud*);
unsigned NBTermineaux (struct noeud*);
unsigned hauteur(struct noeud*);
int evaluer_expression(struct noeud*);
float evaluer_Relle(struct noeud*);





