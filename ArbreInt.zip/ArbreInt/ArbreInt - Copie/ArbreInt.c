
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include "ArbreInt.h"
struct noeud * creer_arbre (void) {
   return(NULL);
}
unsigned arbre_vide (struct noeud *ab) {
  return(ab==NULL);
}
struct noeud* construire (int info, struct noeud*g, struct noeud*d) {
  struct noeud* ab;
  ab= (struct noeud*) malloc (sizeof(struct noeud));
  ab->info=info;
  ab->sag=g;
  ab->sad=d;
  return(ab);
}
struct noeud* gauche (struct noeud* ab) {
  assert(!arbre_vide(ab));
  return(ab->sag);
}
struct noeud* droite (struct noeud* ab)  {
  assert(!arbre_vide(ab));
  return(ab->sad);
}
int lire_racine(struct noeud *ab) {
  assert(!arbre_vide(ab));
  return ab->info;
}

void afficher(struct noeud *ab) {
   printf("%d ", ab->info);
}
void incrementer(struct noeud *ab) {
   ab->info ++ ;
}

void parcoursInfixe(struct noeud *ab, void (*oper)(struct noeud *)) { /*GRD*/
   if (ab) {
       parcoursInfixe(ab->sag, oper);
       oper(ab);
       parcoursInfixe(ab->sad, oper);
   }
}

unsigned Taille (struct noeud* ab){
    if (ab==NULL)
        return 0;
    else
        return 1+ Taille(ab->sag)+Taille (ab->sag);

}

unsigned NBTermineaux (struct noeud* ab){
    if (ab==NULL)
        return 0;
    else {
            if ((ab->sag==NULL) && (ab->sad==NULL))
                 return 1;
            else
                return NBTermineaux (ab->sag)+ NBTermineaux(ab->sag);
    }
}

/*solution 1*
unsigned hauteur (struct noeud *ab) {
  if (ab == NULL)
    return 0;
  else
        return (hauteur(ab->sag)>hauteur(ab->sad))? 1+hauteur(ab->sag): 1+hauteur(ab->sad);

}
*/
/* solution 2*/
unsigned hauteur (struct noeud *ab) {
  unsigned hauteur_g,hauteur_d;
  if (ab == NULL)
    return 0;
  else {
    hauteur_g = hauteur (ab->sag);
    hauteur_d = hauteur(ab->sad);
    if (hauteur_g > hauteur_d)
      return hauteur_g + 1;
    else
      return hauteur_d + 1;

  }
}
int Max3Int (int a, int b, int c){
    if (a>=b && a>=c)
        return a;
    else
        if (b>=c)
            return b;
        else
            return c;
}

int max_value(struct noeud* ab) {
    /*si l'arbre est vide, renvoyer une valeur par d�faut*/
    if (ab == NULL)
        return INT_MIN;
        /* INT_MIN est une constante d�finie dans la biblioth�que <limits.h>,
        qui contient la plus petite valeur possible pour un int*/

    return Max3Int (ab->info,  max_value(ab->sag), max_value(ab->sad));

}




