
#include "Liste.h"

void creerMatCreuse();
struct cellule* ElementAT(unsigned ligne, unsigned col);
void ModifElem(int info, unsigned ligne, unsigned col);
void afficherMatCreuse();

