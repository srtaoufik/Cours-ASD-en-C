

#include <stdlib.h>
#include <assert.h>
#include "Arbre.h"
struct noeud * creer_arbre (void) {
   return(NULL);
}
unsigned arbre_vide (struct noeud *ab) {
  return(ab==NULL);
}
struct noeud* construire (char info, struct noeud*g, struct noeud*d) {
  struct noeud* ab;
  ab= (struct noeud*) malloc (sizeof(struct noeud));
  ab->info=info;
  ab->sag=g;
  ab->sad=d;
  return(ab);
}
struct noeud* gauche (struct noeud* ab) {
  assert(!arbre_vide(ab));
  return(ab->sag);
}
struct noeud* droite (struct noeud* ab)  {
  assert(!arbre_vide(ab));
  return(ab->sad);
}
char lire_racine(struct noeud *ab) {
  assert(!arbre_vide(ab));
  return ab->info;
}

void visiter (struct noeud *ab) {
   printf("%c ", ab->info);
}

void parcoursInfixe(struct noeud *ab) {
   if (ab) {
       parcoursInfixe(ab->sag);
       visiter(ab);
       parcoursInfixe(ab->sad);
   }
}

unsigned Taille (struct noeud* ab){
    if (ab==NULL)
        return 0;
    else
        return 1+ Taille(ab->sag)+Taille (ab->sag);

}

unsigned NBTermineaux (struct noeud* ab){
    if (ab==NULL)
        return 0;
    else {
            if ((ab->sag==NULL) && (ab->sad==NULL))
                 return 1;
            else
                return NBTermineaux (ab->sag)+ NBTermineaux(ab->sag);
    }
}

/*solution 1*
unsigned hauteur (struct noeud *ab) {
  if (ab == NULL)
    return 0;
  else
        return (hauteur(ab->sag)>hauteur(ab->sad))? 1+hauteur(ab->sag): 1+hauteur(ab->sad);

}
*/
/* solution 2*/
unsigned hauteur (struct noeud *ab) {
  unsigned hauteur_g,hauteur_d;
  if (ab == NULL)
    return 0;
  else {
    hauteur_g = hauteur (ab->sag);
    hauteur_d = hauteur(ab->sad);
    if (hauteur_g > hauteur_d)
      return hauteur_g + 1;
    else
      return hauteur_d + 1;

  }
}

float evaluer_Relle(struct noeud* ab) {
    float droite, gauche;
    /* si le n�ud est un terminal, renvoyer sa valeur */
    if (ab->sag == NULL && ab->sad == NULL)
       return atof(& ab->info);
    /* sinon, �valuer les sous-expressions et appliquer l'op�rateur */
    else {
        gauche = evaluer_Relle(ab->sag);
        droite = evaluer_Relle(ab->sad);
        switch(ab->info) {
            case '+': return gauche + droite;
            case '-': return gauche - droite;
            case '*': return gauche * droite;
            case '/': return gauche / droite;
        }
    }
}
int evaluer_expression (struct noeud* ab) {
    int droite, gauche;
    /* si le n�ud est un terminal, renvoyer sa valeur */
    if (ab->sag == NULL && ab->sad == NULL)
       return atol(& ab->info);
     /* return 48- ab->info ;  sol 2 */
    /* sinon, �valuer les sous-expressions et appliquer l'op�rateur */
    else {
        gauche = evaluer_expression(ab->sag);
        droite = evaluer_expression(ab->sad);
        switch(ab->info) {
            case '+': return gauche + droite;
            case '-': return gauche - droite;
            case '*': return gauche * droite;
            case '/': return gauche / droite;
        }
    }
}






